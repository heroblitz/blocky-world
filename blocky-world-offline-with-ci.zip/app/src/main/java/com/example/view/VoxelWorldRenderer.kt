package com.example.view

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import com.example.data.BlockEntity
import com.example.viewmodel.EditMode
import com.example.viewmodel.Particle3D
import kotlin.math.cos
import kotlin.math.sin

data class DrawnFace(
    val block: BlockEntity,
    val faceName: String,
    val points: List<Offset>,
    val normalX: Int,
    val normalY: Int,
    val normalZ: Int,
    val ez: Float // View depth for tap sorting
)

// Helper function to interpolate colors for the day/night sky cycle
fun interpolateColor(c1: Color, c2: Color, bias: Float): Color {
    val b = bias.coerceIn(0f, 1f)
    return Color(
        red = c1.red + (c2.red - c1.red) * b,
        green = c1.green + (c2.green - c1.green) * b,
        blue = c1.blue + (c2.blue - c1.blue) * b,
        alpha = c1.alpha + (c2.alpha - c1.alpha) * b
    )
}

// Calculate the sky background based on timeOfDay (0.0 to 1.0)
fun getSkyColor(time: Float): Color {
    return when {
        time < 0.15f -> {
            // Midnight to early dawn: Navy Slate to Magenta Purple
            val ratio = time / 0.15f
            interpolateColor(Color(0xFF0F172A), Color(0xFF581C87), ratio)
        }
        time < 0.25f -> {
            // Early dawn to Sunrise: Magenta Purple to Soft Coral/Orange
            val ratio = (time - 0.15f) / 0.10f
            interpolateColor(Color(0xFF581C87), Color(0xFFF97316), ratio)
        }
        time < 0.35f -> {
            // Sunrise to Day: Coral to Sky Blue
            val ratio = (time - 0.25f) / 0.10f
            interpolateColor(Color(0xFFF97316), Color(0xFF38BDF8), ratio)
        }
        time < 0.65f -> {
            // Full Day: Bright Blue to Clean Cyan
            val ratio = (time - 0.35f) / 0.30f
            interpolateColor(Color(0xFF38BDF8), Color(0xFF0EA5E9), ratio)
        }
        time < 0.78f -> {
            // Day to Sunset: Blue to Vivid Peach Orange
            val ratio = (time - 0.65f) / 0.13f
            interpolateColor(Color(0xFF0EA5E9), Color(0xFFF97316), ratio)
        }
        time < 0.88f -> {
            // Sunset to Late Twilight: Peach Orange to Dark Indigo
            val ratio = (time - 0.78f) / 0.10f
            interpolateColor(Color(0xFFF97316), Color(0xFF1E1B4B), ratio)
        }
        else -> {
            // Twilight to Midnight: Dark Indigo back to Navy Slate
            val ratio = (time - 0.88f) / 0.12f
            interpolateColor(Color(0xFF1E1B4B), Color(0xFF0F172A), ratio)
        }
    }
}

// Check if raw screen tap is inside drawn face quadrilateral
fun isPointInQuad(p: Offset, points: List<Offset>): Boolean {
    if (points.size != 4) return false
    
    // Cross product sign checking for convex quad
    var signState = 0
    for (i in 0..3) {
        val v1 = points[i]
        val v2 = points[(i + 1) % 4]
        
        // cross = (X2 - X1) * (Py - Y1) - (Y2 - Y1) * (Px - X1)
        val cross = (v2.x - v1.x) * (p.y - v1.y) - (v2.y - v1.y) * (p.x - v1.x)
        if (cross != 0f) {
            val sign = if (cross > 0) 1 else -1
            if (signState == 0) {
                signState = sign
            } else if (signState != sign) {
                return false
            }
        }
    }
    return true
}

@Composable
fun VoxelWorldRenderer(
    blocks: List<BlockEntity>,
    cursorX: Int,
    cursorY: Int,
    cursorZ: Int,
    cameraYaw: Float,
    cameraPitch: Float,
    cameraZoom: Float,
    panOffsetX: Float,
    panOffsetY: Float,
    selectedBlockType: String,
    editMode: EditMode,
    activeParticles: List<Particle3D>,
    timeOfDay: Float,
    onBlockFaceClicked: (x: Int, y: Int, z: Int, normalX: Int, normalY: Int, normalZ: Int) -> Unit,
    onBlockClicked: (x: Int, y: Int, z: Int) -> Unit,
    onRotateCamera: (yawDelta: Float, pitchDelta: Float) -> Unit,
    modifier: Modifier = Modifier
) {
    // Collect the drawn faces so we can perform click casting
    val drawnFacesList = remember { mutableStateListOf<DrawnFace>() }

    Box(
        modifier = modifier
            .fillMaxSize()
            .pointerInput(cameraYaw, cameraPitch) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    // Drag sensitivity
                    val yawDelta = -dragAmount.x * 0.007f
                    val pitchDelta = -dragAmount.y * 0.007f
                    onRotateCamera(yawDelta, pitchDelta)
                }
            }
            .pointerInput(Unit) {
                // Handle tapping with Point-in-Polygon detection
                detectDragGestures(
                    onDragStart = { startOffset ->
                        // Loop through faces backwards (closest first)
                        synchronized(drawnFacesList) {
                            var faceFound = false
                            for (i in drawnFacesList.indices.reversed()) {
                                val df = drawnFacesList[i]
                                if (isPointInQuad(startOffset, df.points)) {
                                    // Found the intersected face!
                                    if (editMode == EditMode.BUILD) {
                                        onBlockFaceClicked(
                                            df.block.x, df.block.y, df.block.z,
                                            df.normalX, df.normalY, df.normalZ
                                        )
                                    } else if (editMode == EditMode.BREAK) {
                                        onBlockClicked(df.block.x, df.block.y, df.block.z)
                                    } else {
                                        // CURSOR Focus Select
                                        onBlockClicked(df.block.x, df.block.y, df.block.z)
                                    }
                                    faceFound = true
                                    break
                                }
                            }
                        }
                    },
                    onDrag = { _, _ -> }
                )
            }
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .testTag("voxel_canvas")
        ) {
            val canvasWidth = size.width
            val canvasHeight = size.height
            val centerX = canvasWidth / 2f
            val centerY = canvasHeight / 2f

            // Dynamic sky gradient background drawing
            val skyColor = getSkyColor(timeOfDay)
            drawRect(
                color = skyColor,
                topLeft = Offset(0f, 0f),
                size = size
            )

            // Grid bounds definitions
            val gridBounds = 16
            val gridCenterX = 7.5f
            val gridCenterY = 7.5f
            val gridCenterZ = 7.5f

            // Calculate precise 3D camera position relative to grid center to check visibility
            val camX = cameraZoom * cos(cameraPitch) * sin(cameraYaw)
            val camY = cameraZoom * sin(cameraPitch)
            val camZ = -cameraZoom * cos(cameraPitch) * cos(cameraYaw)

            val camWorldX = gridCenterX + camX
            val camWorldY = gridCenterY + camY
            val camWorldZ = gridCenterZ + camZ

            // Define projection mathematics
            fun projectPoint(x: Float, y: Float, z: Float): Offset {
                val dx = x - gridCenterX
                val dy = y - gridCenterY
                val dz = z - gridCenterZ

                // Yaw rotation
                val rx = dx * cos(cameraYaw) - dz * sin(cameraYaw)
                val rz = dx * sin(cameraYaw) + dz * cos(cameraYaw)
                val ry = dy

                // Pitch rotation
                val ex = rx
                val ey = ry * cos(cameraPitch) - rz * sin(cameraPitch)
                val ez = ry * sin(cameraPitch) + rz * cos(cameraPitch)

                val depth = ez + cameraZoom
                val safeDepth = if (depth < 0.1f) 0.1f else depth

                val scaleFactor = canvasWidth * 0.9f
                val sx = centerX + (ex * scaleFactor / safeDepth) + panOffsetX
                val sy = centerY - (ey * scaleFactor / safeDepth) + panOffsetY
                return Offset(sx, sy)
            }

            // Draw a boundary grid wireframe at the base of the world (Y = 0)
            val gridColor = Color(0x3EFFFFFF)
            for (i in 0..gridBounds) {
                // Lines along X axis
                val startX = projectPoint(0f, 0f, i.toFloat())
                val endX = projectPoint(gridBounds.toFloat(), 0f, i.toFloat())
                drawLine(color = gridColor, start = startX, end = endX, strokeWidth = 2f)

                // Lines along Z axis
                val startZ = projectPoint(i.toFloat(), 0f, 0f)
                val endZ = projectPoint(i.toFloat(), 0f, gridBounds.toFloat())
                drawLine(color = gridColor, start = startZ, end = endZ, strokeWidth = 2f)
            }

            // Calculate camera eye-space depth (ez) for all world blocks for Painter's Algorithm sorting!
            // Larger eye-space z means further away from camera
            data class SortedBlock(val block: BlockEntity, val depth: Float)

            val sortedBlocks = blocks.map { b ->
                val dx = (b.x + 0.5f) - gridCenterX
                val dy = (b.y + 0.5f) - gridCenterY
                val dz = (b.z + 0.5f) - gridCenterZ

                val rx = dx * cos(cameraYaw) - dz * sin(cameraYaw)
                val rz = dx * sin(cameraYaw) + dz * cos(cameraYaw)
                val ry = dy

                val ez = ry * sin(cameraPitch) + rz * cos(cameraPitch)
                SortedBlock(b, ez)
            }.sortedByDescending { it.depth }

            // Temporary list to build the tapped faces list
            val localDrawnFacesList = mutableListOf<DrawnFace>()

            // Draw blocks from farthest to closest!
            sortedBlocks.forEach { sorted ->
                val b = sorted.block
                val bx = b.x.toFloat()
                val by = b.y.toFloat()
                val bz = b.z.toFloat()

                // Calculate whether each of the 6 faces are visible!
                // Since blocks are axis-aligned, visibility checking is incredibly simple:
                val topVisible = camWorldY > by + 0.5f
                val bottomVisible = camWorldY < by + 0.5f
                val rightVisible = camWorldX > bx + 0.5f
                val leftVisible = camWorldX < bx + 0.5f
                val frontVisible = camWorldZ > bz + 0.5f
                val backVisible = camWorldZ < bz + 0.5f

                // Project 8 vertices of the block
                val v000 = projectPoint(bx, by, bz)
                val v100 = projectPoint(bx + 1f, by, bz)
                val v110 = projectPoint(bx + 1f, by + 1f, bz)
                val v010 = projectPoint(bx, by + 1f, bz)
                val v001 = projectPoint(bx, by, bz + 1f)
                val v101 = projectPoint(bx + 1f, by, bz + 1f)
                val v111 = projectPoint(bx + 1f, by + 1f, bz + 1f)
                val v011 = projectPoint(bx, by + 1f, bz + 1f)

                // Define Base Materials Styling Colors
                val baseColorHex = when (b.type) {
                    "GRASS" -> "#8D5F3A" // Dirt body, green top handled in face drawer
                    "DIRT" -> "#8D4F2A"
                    "STONE" -> "#95A5A6"
                    "WOOD" -> "#8E44AD" // Purple-wood / Oak Wood: brown hex
                    "LEAVES" -> "#1E824C"
                    "BRICK" -> "#CD6155"
                    "GLASS" -> "#34495E"
                    "SAND" -> "#F4D03F"
                    "WATER" -> "#2980B9"
                    "TNT" -> "#E74C3C"
                    "LAVA" -> "#D35400"
                    "DIAMOND" -> "#4DEEEA"
                    "GOLD" -> "#F1C40F"
                    else -> "#BDC3C7"
                }

                // Parse core material properties
                val parsedColor = Color(android.graphics.Color.parseColor(baseColorHex))

                // Helper block face renderer
                fun drawBlockFace(
                    faceName: String,
                    p0: Offset, p1: Offset, p2: Offset, p3: Offset,
                    normalX: Int, normalY: Int, normalZ: Int,
                    lightMult: Float
                ) {
                    val facePath = Path().apply {
                        moveTo(p0.x, p0.y)
                        lineTo(p1.x, p1.y)
                        lineTo(p2.x, p2.y)
                        lineTo(p3.x, p3.y)
                        close()
                    }

                    // Water and Glass support alpha blending
                    val alphaValue = when (b.type) {
                        "WATER" -> 0.65f
                        "GLASS" -> 0.45f
                        else -> 1.0f
                    }

                    // Compute shading color
                    val finalColor = when {
                        b.type == "GRASS" && faceName == "TOP" -> {
                            Color(0xFF2ECC71) // Top of grass is bright solid green!
                        }
                        b.type == "WOOD" -> {
                            if (faceName == "TOP" || faceName == "BOTTOM") Color(0xFFD35400) else Color(0xFF784212)
                        }
                        else -> parsedColor
                    }

                    // Apply flat shading intensity multiplier
                    val shadedColor = Color(
                        red = (finalColor.red * lightMult).coerceIn(0f, 1f),
                        green = (finalColor.green * lightMult).coerceIn(0f, 1f),
                        blue = (finalColor.blue * lightMult).coerceIn(0f, 1f),
                        alpha = alphaValue
                    )

                    // Fill face
                    drawPath(path = facePath, color = shadedColor, style = Fill)

                    // Draw block detailed aesthetics to make them look authentic and polished
                    when (b.type) {
                        "GRASS" -> {
                            if (faceName != "TOP" && faceName != "BOTTOM") {
                                // Draw the lovely green fringe on the upper 20% of dirt face
                                val grassFringePath = Path().apply {
                                    moveTo(p0.x, p0.y)
                                    lineTo(p1.x, p1.y) // Top bar of quadrilaterals

                                    // Interpolated points down the sides
                                    val sideA = Offset(
                                        p0.x + (p3.x - p0.x) * 0.25f,
                                        p0.y + (p3.y - p0.y) * 0.25f
                                    )
                                    val sideB = Offset(
                                        p1.x + (p2.x - p1.x) * 0.25f,
                                        p1.y + (p2.y - p1.y) * 0.25f
                                    )
                                    lineTo(sideB.x, sideB.y)
                                    lineTo(sideA.x, sideA.y)
                                    close()
                                }
                                val fColor = Color(0xFF27AE60)
                                val shadedGrassFringe = Color(
                                    red = fColor.red * lightMult,
                                    green = fColor.green * lightMult,
                                    blue = fColor.blue * lightMult,
                                    alpha = 1.0f
                                )
                                drawPath(
                                    path = grassFringePath,
                                    color = shadedGrassFringe,
                                    style = Fill
                                )
                            }
                        }
                        "STONE" -> {
                            // Cobblestone border
                            drawPath(
                                path = facePath,
                                color = Color(0x3E000000),
                                style = Stroke(width = 1.5f)
                            )
                        }
                        "GLASS" -> {
                            // Classic diagonal glass scratch mark
                            drawLine(
                                color = Color(0xAAFFFFFF),
                                start = Offset((p0.x + p2.x) / 2f, (p0.y + p2.y) / 2f),
                                end = Offset(p2.x - (p2.x - p0.x) * 0.1f, p2.y - (p2.y - p0.y) * 0.1f),
                                strokeWidth = 2f
                            )
                        }
                        "BRICK" -> {
                            // brick line pattern
                            drawLine(
                                color = Color(0x4E000000),
                                start = Offset((p0.x + p3.x) / 2f, (p0.y + p3.y) / 2f),
                                end = Offset((p1.x + p2.x) / 2f, (p1.y + p2.y) / 2f),
                                strokeWidth = 2.0f
                            )
                        }
                        "DIAMOND" -> {
                            // Diamond mineral flecks
                            drawCircle(
                                color = Color(0xFF2CEADE),
                                radius = 6f,
                                center = Offset((p0.x + p2.x) / 2f, (p0.y + p2.y) / 2f)
                            )
                        }
                        "GOLD" -> {
                            // Gold mineral flecks
                            drawCircle(
                                color = Color(0xFFF39C12),
                                radius = 6f,
                                center = Offset((p0.x + p2.x) / 2f, (p0.y + p2.y) / 2f)
                            )
                        }
                        "TNT" -> {
                            // Red with stripes or line crosses
                            drawLine(
                                color = Color.White,
                                start = Offset((p0.x + p3.x) / 2f, (p0.y + p3.y) / 2f),
                                end = Offset((p1.x + p2.x) / 2f, (p1.y + p2.y) / 2f),
                                strokeWidth = 8.0f
                            )
                            drawLine(
                                color = Color.Black,
                                start = Offset((p0.x + p3.x) / 2f, (p0.y + p3.y) / 2f),
                                end = Offset((p1.x + p2.x) / 2f, (p1.y + p2.y) / 2f),
                                strokeWidth = 1.0f
                            )
                        }
                    }

                    // Flat dark outlines for voxel style definition
                    drawPath(
                        path = facePath,
                        color = Color(0x27000000),
                        style = Stroke(width = 1.2f)
                    )

                    // Track this face's polygon vertices on screen for physical tapping
                    localDrawnFacesList.add(
                        DrawnFace(
                            block = b,
                            faceName = faceName,
                            points = listOf(p0, p1, p2, p3),
                            normalX = normalX,
                            normalY = normalY,
                            normalZ = normalZ,
                            ez = sorted.depth
                        )
                    )
                }

                // RENDER VISIBLE FACES IN ORDER:
                // Shader multipliers for realistic 3D volumetric shadows!
                if (topVisible) {
                    drawBlockFace(
                        "TOP", v010, v011, v111, v110,
                        0, 1, 0, 0.98f
                    )
                }
                if (bottomVisible) {
                    drawBlockFace(
                        "BOTTOM", v000, v100, v101, v001,
                        0, -1, 0, 0.40f
                    )
                }
                if (leftVisible) {
                    drawBlockFace(
                        "LEFT", v000, v001, v011, v010,
                        -1, 0, 0, 0.65f
                    )
                }
                if (rightVisible) {
                    drawBlockFace(
                        "RIGHT", v100, v110, v111, v101,
                        1, 0, 0, 0.85f
                    )
                }
                if (frontVisible) {
                    drawBlockFace(
                        "FRONT", v001, v101, v111, v011,
                        0, 0, 1, 0.80f
                    )
                }
                if (backVisible) {
                    drawBlockFace(
                        "BACK", v000, v010, v110, v100,
                        0, 0, -1, 0.55f
                    )
                }
            }

            // Flush the newly drawn faces for the touch screen thread safely
            synchronized(drawnFacesList) {
                drawnFacesList.clear()
                drawnFacesList.addAll(localDrawnFacesList)
            }

            // Draw the active 3D particles on screen!
            activeParticles.forEach { p ->
                val sizeVal = p.size
                val pixelOffset = projectPoint(p.x, p.y, p.z)
                val c = Color(android.graphics.Color.parseColor(p.colorHex))
                drawRect(
                    color = c.copy(alpha = p.life),
                    topLeft = Offset(pixelOffset.x - sizeVal / 2f, pixelOffset.y - sizeVal / 2f),
                    size = androidx.compose.ui.geometry.Size(sizeVal, sizeVal)
                )
            }

            // Draw our highlighted neon 3D Builder Cursor!
            val cx = cursorX.toFloat()
            val cy = cursorY.toFloat()
            val cz = cursorZ.toFloat()

            // Project 8 cursor wireframe vertices
            val cv000 = projectPoint(cx, cy, cz)
            val cv100 = projectPoint(cx + 1f, cy, cz)
            val cv110 = projectPoint(cx + 1f, cy + 1f, cz)
            val cv010 = projectPoint(cx, cy + 1f, cz)
            val cv001 = projectPoint(cx, cy, cz + 1f)
            val cv101 = projectPoint(cx + 1f, cy, cz + 1f)
            val cv111 = projectPoint(cx + 1f, cy + 1f, cz + 1f)
            val cv011 = projectPoint(cx, cy + 1f, cz + 1f)

            // Select a vibrant glowing border color depending on current Active EditMode
            val cursorColor = when (editMode) {
                EditMode.BUILD -> Color(0xFFF1C40F) // Bright Gold
                EditMode.BREAK -> Color(0xFFE74C3C) // Danger Red
                EditMode.CURSOR -> Color(0xFF2980B9) // Cyan/Blue
            }

            val cursorStrokeWidth = 4f

            // Helper to draw lines between offsets
            fun drawCursorEdge(p1: Offset, p2: Offset) {
                drawLine(
                    color = cursorColor,
                    start = p1,
                    end = p2,
                    strokeWidth = cursorStrokeWidth,
                    pathEffect = null
                )
            }

            // 12 edges of the 3D Cursor Box!
            drawCursorEdge(cv000, cv100)
            drawCursorEdge(cv100, cv110)
            drawCursorEdge(cv110, cv010)
            drawCursorEdge(cv010, cv000)

            drawCursorEdge(cv001, cv101)
            drawCursorEdge(cv101, cv111)
            drawCursorEdge(cv111, cv011)
            drawCursorEdge(cv011, cv001)

            drawCursorEdge(cv000, cv001)
            drawCursorEdge(cv100, cv101)
            drawCursorEdge(cv110, cv111)
            drawCursorEdge(cv010, cv011)

            // Draw small blinking dot inside the cursor box center
            val scaleFactor = canvasWidth * 0.9f
            val lookAtOffset = projectPoint(cx + 0.5f, cy + 0.5f, cz + 0.5f)
            drawCircle(
                color = cursorColor,
                radius = 10f,
                center = lookAtOffset
            )
        }
    }
}

package com.example.view

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.WorldEntity
import com.example.viewmodel.EditMode
import com.example.viewmodel.VoxelViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VoxelGameScreen(
    viewModel: VoxelViewModel,
    modifier: Modifier = Modifier
) {
    val screenState = viewModel.screenState
    val worlds by viewModel.worlds.collectAsState()
    val worldBlocks by viewModel.worldBlocks.collectAsState()
    val currentWorld = viewModel.currentWorld

    // Local dialogs
    var showCreateWorldDialog by remember { mutableStateOf(false) }
    var showSettingsBottomSheet by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A)) //Basalt Dark Slate Base
    ) {
        if (screenState == "HOME") {
            // ==========================================
            // GORGEOUS RETRO SANDBOX HOME SCREEN
            // ==========================================
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(24.dp)
                    .safeDrawingPadding(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(modifier = Modifier.height(20.dp))

                // App Title Banner
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(Color(0xFF334155), Color(0xFF1E293B))
                                )
                            )
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "⛏️ BLOCK BUILDER 3D ⛏️",
                            fontSize = 26.sp,
                            fontWeight = FontWeight.ExtraBold,
                            fontFamily = FontFamily.Monospace,
                            color = Color(0xFFF1C40F),
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Offline Voxel Sandbox Engine",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            fontFamily = FontFamily.SansSerif,
                            color = Color(0xFF94A3B8),
                            textAlign = TextAlign.Center
                        )
                    }
                }

                Spacer(modifier = Modifier.height(28.dp))

                // Action Bar: Create New World
                Button(
                    onClick = { showCreateWorldDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .testTag("create_world_button")
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "Create")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "GENERATE NEW WORLD",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Worlds List
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.List,
                        contentDescription = "Worlds",
                        tint = Color(0xFF94A3B8)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Saved Worlds (${worlds.size})",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                if (worlds.isEmpty()) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                "No Worlds Saved Yet",
                                color = Color.White,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                "Click the button above to generate a new blocky 3D sandbox play arena!",
                                color = Color(0xFF94A3B8),
                                fontSize = 13.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                } else {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        worlds.forEach { world ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = world.name,
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        val df = SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault())
                                        Text(
                                            text = "Last Edit: " + df.format(Date(world.lastUpdated)),
                                            fontSize = 12.sp,
                                            color = Color(0xFF94A3B8)
                                        )
                                        Text(
                                            text = "Generator preset: " + world.type.uppercase(),
                                            fontSize = 11.sp,
                                            color = Color(0xFF10B981),
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }

                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        // Delete Button
                                        IconButton(
                                            onClick = { viewModel.deleteWorld(world) },
                                            colors = IconButtonDefaults.iconButtonColors(
                                                containerColor = Color(0x1CE74C3C)
                                            )
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Delete,
                                                contentDescription = "Delete World",
                                                tint = Color(0xFFE74C3C)
                                            )
                                        }

                                        // Launch Game Button
                                        Button(
                                            onClick = { viewModel.loadWorld(world) },
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF1C40F)),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Text(
                                                "PLAY",
                                                color = Color(0xFF0F172A),
                                                fontWeight = FontWeight.ExtraBold
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // ==========================================
            // IMMERSIVE 3D CELLULAR SANDBOX EDITOR SCREEN
            // ==========================================
            Box(modifier = Modifier.fillMaxSize()) {

                // Full-Screen 3D Voxel Engine Canvas
                VoxelWorldRenderer(
                    blocks = worldBlocks,
                    cursorX = viewModel.cursorX,
                    cursorY = viewModel.cursorY,
                    cursorZ = viewModel.cursorZ,
                    cameraYaw = viewModel.cameraYaw,
                    cameraPitch = viewModel.cameraPitch,
                    cameraZoom = viewModel.cameraZoom,
                    panOffsetX = viewModel.panOffsetX,
                    panOffsetY = viewModel.panOffsetY,
                    selectedBlockType = viewModel.selectedBlockType,
                    editMode = viewModel.activeEditMode,
                    activeParticles = viewModel.activeParticles,
                    timeOfDay = viewModel.timeOfDay,
                    onBlockFaceClicked = { bx, by, bz, nx, ny, nz ->
                        viewModel.clickPlaceBlockAdjacent(bx, by, bz, nx, ny, nz)
                    },
                    onBlockClicked = { bx, by, bz ->
                        if (viewModel.activeEditMode == EditMode.BREAK) {
                            viewModel.clickBreakBlock(bx, by, bz)
                        } else {
                            // Snap cursor focus to selected block coordinates
                            viewModel.cursorX = bx
                            viewModel.cursorY = by
                            viewModel.cursorZ = bz
                        }
                    },
                    onRotateCamera = { yawDelta, pitchDelta ->
                        viewModel.cameraYaw = (viewModel.cameraYaw + yawDelta) % (2f * Math.PI.toFloat())
                        viewModel.cameraPitch = (viewModel.cameraPitch + pitchDelta).coerceIn(-1.4f, 1.4f)
                    }
                )

                // ==========================================
                // OVERLAY HEADS-UP DISPLAY (HUD)
                // ==========================================

                // TOP MENU ACTION BAR
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                        .safeDrawingPadding()
                        .align(Alignment.TopCenter),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Quit/Save Button
                    IconButton(
                        onClick = { viewModel.leaveToMain() },
                        colors = IconButtonDefaults.iconButtonColors(containerColor = Color(0xB31E293B)),
                        modifier = Modifier.size(48.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Save and Return Home",
                            tint = Color.White
                        )
                    }

                    // World Details HUD
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xB31E293B)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = currentWorld?.name ?: "Unknown World",
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                fontSize = 14.sp
                            )
                            Text(
                                text = "Blocks: ${worldBlocks.size} | Cursor: (${viewModel.cursorX}, ${viewModel.cursorY}, ${viewModel.cursorZ})",
                                fontSize = 11.sp,
                                color = Color(0xFFF1C40F),
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    // Settings Drawer Opener
                    IconButton(
                        onClick = { showSettingsBottomSheet = true },
                        colors = IconButtonDefaults.iconButtonColors(containerColor = Color(0xB31E293B)),
                        modifier = Modifier.size(48.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "World Settings",
                            tint = Color.White
                        )
                    }
                }

                // FLOATING CAMERA CONTROLLER (ZOOM & SWIVEL HELPER)
                Column(
                    modifier = Modifier
                        .align(Alignment.CenterEnd)
                        .padding(end = 16.dp)
                        .background(Color(0x8D1E293B), shape = RoundedCornerShape(12.dp))
                        .padding(8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "CAMERA",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.LightGray
                    )
                    IconButton(
                        onClick = { viewModel.cameraZoom = (viewModel.cameraZoom - 1.5f).coerceIn(8f, 40f) },
                        colors = IconButtonDefaults.iconButtonColors(containerColor = Color(0xFF334155)),
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(imageVector = Icons.Default.KeyboardArrowUp, contentDescription = "Zoom In", tint = Color.White)
                    }
                    Text(
                        text = "ZOOM",
                        fontSize = 10.sp,
                        color = Color.White,
                        fontFamily = FontFamily.Monospace
                    )
                    IconButton(
                        onClick = { viewModel.cameraZoom = (viewModel.cameraZoom + 1.5f).coerceIn(8f, 40f) },
                        colors = IconButtonDefaults.iconButtonColors(containerColor = Color(0xFF334155)),
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(imageVector = Icons.Default.KeyboardArrowDown, contentDescription = "Zoom Out", tint = Color.White)
                    }
                }

                // LEFT SIDEBAR: 3D BUILDER CURSOR CONTROL D-PAD
                Column(
                    modifier = Modifier
                        .align(Alignment.CenterStart)
                        .padding(start = 16.dp)
                        .background(Color(0x8D1E293B), shape = RoundedCornerShape(16.dp))
                        .padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "3D D-PAD",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFFF1C40F),
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    // Height (Y Axis) control
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = { viewModel.cursorY = (viewModel.cursorY + 1).coerceIn(0, 15) },
                            colors = IconButtonDefaults.iconButtonColors(containerColor = Color(0xFF10B981)),
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(imageVector = Icons.Default.KeyboardArrowUp, contentDescription = "Up Height", tint = Color.White)
                        }
                        Text("Y", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        IconButton(
                            onClick = { viewModel.cursorY = (viewModel.cursorY - 1).coerceIn(0, 15) },
                            colors = IconButtonDefaults.iconButtonColors(containerColor = Color(0xFFEF4444)),
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(imageVector = Icons.Default.KeyboardArrowDown, contentDescription = "Down Height", tint = Color.White)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Horizontal D-Pad block movement
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        // Forward (Z-)
                        IconButton(
                            onClick = { viewModel.cursorZ = (viewModel.cursorZ - 1).coerceIn(0, 15) },
                            colors = IconButtonDefaults.iconButtonColors(containerColor = Color(0xFF334155)),
                            modifier = Modifier.size(34.dp)
                        ) {
                            Icon(imageVector = Icons.Default.KeyboardArrowUp, contentDescription = "Z- Forward", tint = Color.White)
                        }

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Left (X-)
                            IconButton(
                                onClick = { viewModel.cursorX = (viewModel.cursorX - 1).coerceIn(0, 15) },
                                colors = IconButtonDefaults.iconButtonColors(containerColor = Color(0xFF334155)),
                                modifier = Modifier.size(34.dp)
                            ) {
                                Icon(imageVector = Icons.Default.KeyboardArrowLeft, contentDescription = "X- Left", tint = Color.White)
                            }

                            // Center indicator
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .background(Color(0xFF1E293B), shape = CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "XZ",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }

                            // Right (X+)
                            IconButton(
                                onClick = { viewModel.cursorX = (viewModel.cursorX + 1).coerceIn(0, 15) },
                                colors = IconButtonDefaults.iconButtonColors(containerColor = Color(0xFF334155)),
                                modifier = Modifier.size(34.dp)
                            ) {
                                Icon(imageVector = Icons.Default.KeyboardArrowRight, contentDescription = "X+ Right", tint = Color.White)
                            }
                        }

                        // Backward (Z+)
                        IconButton(
                            onClick = { viewModel.cursorZ = (viewModel.cursorZ + 1).coerceIn(0, 15) },
                            colors = IconButtonDefaults.iconButtonColors(containerColor = Color(0xFF334155)),
                            modifier = Modifier.size(34.dp)
                        ) {
                            Icon(imageVector = Icons.Default.KeyboardArrowDown, contentDescription = "Z+ Backward", tint = Color.White)
                        }
                    }
                }

                // ==========================================
                // BOTTOM CONTROLS & RETRO INVENTORY HOTBAR
                // ==========================================
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter)
                        .navigationBarsPadding()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // BUILD & BREAK DIRECT ACTIONS PANEL
                    Row(
                        modifier = Modifier
                            .background(Color(0xCC1E293B), shape = RoundedCornerShape(12.dp))
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Quick click add at cursor
                        Button(
                            onClick = { viewModel.addBlockAtCursor() },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.height(40.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Add, contentDescription = "Add")
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("PLACE", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }

                        // Edit Mode Selector
                        Row(
                            modifier = Modifier
                                .background(Color(0xFF334155), shape = RoundedCornerShape(8.dp))
                                .padding(2.dp)
                        ) {
                            EditModeTab("BUILD", active = viewModel.activeEditMode == EditMode.BUILD) {
                                viewModel.activeEditMode = EditMode.BUILD
                            }
                            EditModeTab("BREAK", active = viewModel.activeEditMode == EditMode.BREAK) {
                                viewModel.activeEditMode = EditMode.BREAK
                            }
                            EditModeTab("ORBIT", active = viewModel.activeEditMode == EditMode.CURSOR) {
                                viewModel.activeEditMode = EditMode.CURSOR
                            }
                        }

                        // Quick click break at cursor
                        Button(
                            onClick = { viewModel.removeBlockAtCursor() },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.height(40.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Delete, contentDescription = "Break")
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("BREAK", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }

                    // RETRO HOTBAR (MATERIAL SELECTOR)
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xE61E293B)),
                        shape = RoundedCornerShape(14.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
                    ) {
                        val materials = listOf(
                            "GRASS" to "🌱 Grass",
                            "DIRT" to "🟫 Dirt",
                            "STONE" to "🪨 Stone",
                            "WOOD" to "🪵 Wood",
                            "LEAVES" to "🍃 Leaf",
                            "BRICK" to "🧱 Brick",
                            "GLASS" to "🪟 Glass",
                            "SAND" to "🏜️ Sand",
                            "WATER" to "💧 Water",
                            "LAVA" to "🔥 Lava",
                            "GOLD" to "🪙 Gold",
                            "DIAMOND" to "💎 Gem",
                            "TNT" to "🧨 TNT"
                        )

                        LazyRow(
                            modifier = Modifier
                                .padding(8.dp)
                                .fillMaxWidth(0.95f),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            items(materials) { (key, label) ->
                                val isSelected = viewModel.selectedBlockType == key
                                Column(
                                    modifier = Modifier
                                        .background(
                                            color = if (isSelected) Color(0xFFF1C40F) else Color(0xFF334155),
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        .clickable {
                                            viewModel.selectedBlockType = key
                                            viewModel.activeEditMode = EditMode.BUILD
                                        }
                                        .padding(horizontal = 12.dp, vertical = 10.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(
                                        text = label,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = if (isSelected) Color(0xFF0F172A) else Color.White
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // ==========================================
        // PERSISTENT NOTIFICATION BANNER / FEEDBACK
        // ==========================================
        viewModel.statusMessage?.let { msg ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF10B981)),
                shape = RoundedCornerShape(50),
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 140.dp)
            ) {
                Text(
                    text = msg,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        // ==========================================
        // DIALOG: CREATE NEW WORLD Presets Form
        // ==========================================
        if (showCreateWorldDialog) {
            AlertDialog(
                onDismissRequest = { showCreateWorldDialog = false },
                containerColor = Color(0xFF1E293B),
                title = {
                    Text(
                        "⛏️ Plan Your Voxel Sandbox",
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                },
                text = {
                    var inputName by remember { mutableStateOf("") }
                    var selectedPreset by remember { mutableStateOf("hills") }

                    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        TextField(
                            value = inputName,
                            onValueChange = { inputName = it },
                            placeholder = { Text("E.g., Castle Base", color = Color.Gray) },
                            label = { Text("World Name") },
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color(0xFF0F172A),
                                unfocusedContainerColor = Color(0xFF0F172A),
                                focusedLabelColor = Color(0xFFF1C40F),
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("world_name_input")
                        )

                        Text(
                            "Procedural Terrain Spawner",
                            color = Color.LightGray,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )

                        // Spawner preset chips Selection
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            PresetSelectionRow("🌲 Survival Hills", desc = "Gentle sine heights, trees, underground gem ores.", active = selectedPreset == "hills") {
                                selectedPreset = "hills"
                            }
                            PresetSelectionRow("🧱 Flat Sandbox", desc = "Super flat grass plain (Y=3). Excellent for pixel builders.", active = selectedPreset == "flat") {
                                selectedPreset = "flat"
                            }
                            PresetSelectionRow("🟦 Skyblock Island", desc = "Small floating home island with an oak tree.", active = selectedPreset == "empty") {
                                selectedPreset = "empty"
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            TextButton(
                                onClick = { showCreateWorldDialog = false },
                                colors = ButtonDefaults.textButtonColors(contentColor = Color.LightGray)
                            ) {
                                Text("CANCEL")
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = {
                                    viewModel.createNewWorld(inputName, selectedPreset)
                                    showCreateWorldDialog = false
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                            ) {
                                Text("GENERATE NOW")
                            }
                        }
                    }
                },
                confirmButton = {}
            )
        }

        // ==========================================
        // SIDE BAR BOTTOM SHEET (WORLD SETTINGS & SUN CYCLE)
        // ==========================================
        if (showSettingsBottomSheet) {
            ModalBottomSheet(
                onDismissRequest = { showSettingsBottomSheet = false },
                containerColor = Color(0xFF1E293B)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp)
                        .navigationBarsPadding(),
                    verticalArrangement = Arrangement.spacedBy(20.dp)
                ) {
                    Text(
                        text = "🛠️ World Master Cheat Panel",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )

                    // Celestial Sun cycle manual override
                    Text(
                        text = "Sun Progression: Time Of Day (" + String.format("%.2f", viewModel.timeOfDay) + ")",
                        color = Color.LightGray,
                        fontSize = 14.sp
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Day cycle auto-running", color = Color.White, fontSize = 13.sp)
                        Switch(
                            checked = viewModel.autoDayCycleEnabled,
                            onCheckedChange = { viewModel.autoDayCycleEnabled = it }
                        )
                    }

                    Slider(
                        value = viewModel.timeOfDay,
                        onValueChange = {
                            viewModel.timeOfDay = it
                        },
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFFF1C40F),
                            activeTrackColor = Color(0xFFF1C40F)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    HorizontalDivider(color = Color(0xFF334155))

                    // Instruction Manual / Helpful tips
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF334155))
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                "💡 Sandboxing Instructions:",
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFF1C40F),
                                fontSize = 12.sp
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                "- DRAG anywhere on 3D engine canvas to rotate angles.\n" +
                                "- PINCH or tap CAMERA ZOOM in the side widget to focus closer.\n" +
                                "- TAP on a block's face in the 3D grid in BUILD mode to plant adjacent blocks automatically!\n" +
                                "- Use the 3D D-PAD on left to fine-tune cursor and click big PLACE/BREAK buttons.",
                                fontSize = 11.sp,
                                color = Color.LightGray,
                                lineHeight = 16.sp
                            )
                        }
                    }

                    // Reset World Blocks Action
                    Button(
                        onClick = {
                            viewModel.clearAllBlocks()
                            showSettingsBottomSheet = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(imageVector = Icons.Default.Delete, contentDescription = "Clear Blocks")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Nuke World Blocks (Wipe Static Data)", fontWeight = FontWeight.SemiBold)
                    }

                    Spacer(modifier = Modifier.height(20.dp))
                }
            }
        }
    }
}

@Composable
fun EditModeTab(label: String, active: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .background(
                color = if (active) Color(0xFFF1C40F) else Color.Transparent,
                shape = RoundedCornerShape(6.dp)
            )
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = if (active) Color(0xFF0F172A) else Color.White
        )
    }
}

@Composable
fun PresetSelectionRow(title: String, desc: String, active: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                color = if (active) Color(0xFF334155) else Color(0x660F172A),
                shape = RoundedCornerShape(8.dp)
            )
            .border(
                width = 2.dp,
                color = if (active) Color(0xFFF1C40F) else Color.Transparent,
                shape = RoundedCornerShape(8.dp)
            )
            .clickable { onClick() }
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(title, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
            Text(desc, color = Color.Gray, fontSize = 11.sp)
        }
    }
}

package com.example.viewmodel

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.sin

enum class EditMode {
    BUILD,
    BREAK,
    CURSOR
}

data class Particle3D(
    var x: Float,
    var y: Float,
    var z: Float,
    var vx: Float,
    var vy: Float,
    var vz: Float,
    val colorHex: String,
    var life: Float, // 1.0f down to 0.0f
    val size: Float
)

class VoxelViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    val repository = WorldRepository(db.worldDao(), db.blockDao())

    // List of all user worlds
    val worlds: StateFlow<List<WorldEntity>> = repository.allWorlds
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Current Loaded World
    var currentWorld by mutableStateOf<WorldEntity?>(null)
        private set

    // Blocks in the currently loaded world, fetched reactively!
    private val _worldBlocks = MutableStateFlow<List<BlockEntity>>(emptyList())
    val worldBlocks: StateFlow<List<BlockEntity>> = _worldBlocks.asStateFlow()

    private var blockObservationJob: Job? = null

    // Screen State: "HOME" or "GAME"
    var screenState by mutableStateOf("HOME")
        private set

    // Camera Orbit State
    var cameraYaw by mutableStateOf(0.7f) // radians
    var cameraPitch by mutableStateOf(0.5f) // radians
    var cameraZoom by mutableStateOf(18.0f) // camera distance (focal size)
    var panOffsetX by mutableStateOf(0f)
    var panOffsetY by mutableStateOf(0f)

    // Editing Cursor State
    var cursorX by mutableStateOf(8)
    var cursorY by mutableStateOf(4)
    var cursorZ by mutableStateOf(8)

    // Editor Variables
    var selectedBlockType by mutableStateOf("GRASS")
    var activeEditMode by mutableStateOf(EditMode.BUILD)

    // Time of day (0.0 .. 1.0). 0.5 is noon, 0.0/1.0 is midnight
    var timeOfDay by mutableStateOf(0.5f) // Noon default
    var autoDayCycleEnabled by mutableStateOf(true)

    // Particles for breaking blocks
    var activeParticles by mutableStateOf<List<Particle3D>>(emptyList())
        private set

    // Feedback notifications / message banner
    var statusMessage by mutableStateOf<String?>(null)
        private set

    init {
        viewModelScope.launch {
            // Check list and create default worlds if user starts empty
            repository.checkAndPrepopulateDefaultWorlds()
            
            // Start particle anim ticks
            launch {
                while (true) {
                    delay(30)
                    updateParticles()
                }
            }

            // Start Day/Night progression if enabled
            launch {
                while (true) {
                    delay(250)
                    if (autoDayCycleEnabled) {
                        timeOfDay = (timeOfDay + 0.002f) % 1.0f
                    }
                }
            }
        }
    }

    // Load world block list reactively
    fun loadWorld(world: WorldEntity) {
        currentWorld = world
        blockObservationJob?.cancel()
        blockObservationJob = viewModelScope.launch {
            repository.getBlocksForWorld(world.id).collect { blocks ->
                _worldBlocks.value = blocks
            }
        }
        screenState = "GAME"
        showFeedback("Entering world: ${world.name}")
    }

    fun leaveToMain() {
        screenState = "HOME"
        currentWorld = null
        _worldBlocks.value = emptyList()
        blockObservationJob?.cancel()
    }

    fun createNewWorld(name: String, type: String) {
        viewModelScope.launch {
            val finalName = name.ifEmpty { "My New World ${System.currentTimeMillis() % 1000}" }
            val newWorld = WorldEntity(name = finalName, type = type)
            val insertedId = repository.insertWorld(newWorld, prepopulate = true)
            
            // Auto open the newly constructed world!
            val fetchedWorld = db.worldDao().getWorldById(insertedId)
            if (fetchedWorld != null) {
                loadWorld(fetchedWorld)
            }
        }
    }

    fun deleteWorld(world: WorldEntity) {
        viewModelScope.launch {
            repository.deleteWorld(world)
            showFeedback("Deleted world: ${world.name}")
        }
    }

    fun showFeedback(msg: String) {
        statusMessage = msg
        viewModelScope.launch {
            delay(2000)
            if (statusMessage == msg) {
                statusMessage = null
            }
        }
    }

    // Game Interactions: Place and Break
    fun addBlockAtCursor() {
        val world = currentWorld ?: return
        viewModelScope.launch {
            repository.addBlock(
                worldId = world.id,
                x = cursorX,
                y = cursorY,
                z = cursorZ,
                type = selectedBlockType
            )
        }
    }

    fun removeBlockAtCursor() {
        val world = currentWorld ?: return
        // First try to spawn particles for the block that exists at this index
        val block = _worldBlocks.value.find { it.x == cursorX && it.y == cursorY && it.z == cursorZ }
        if (block != null) {
            spawnParticles(block.x, block.y, block.z, block.type)
        }
        viewModelScope.launch {
            repository.removeBlock(world.id, cursorX, cursorY, cursorZ)
        }
    }

    fun clickPlaceBlockAdjacent(x: Int, y: Int, z: Int, normalX: Int, normalY: Int, normalZ: Int) {
        val world = currentWorld ?: return
        val targetX = x + normalX
        val targetY = y + normalY
        val targetZ = z + normalZ

        if (targetX in 0..15 && targetY in 0..15 && targetZ in 0..15) {
            cursorX = targetX
            cursorY = targetY
            cursorZ = targetZ
            viewModelScope.launch {
                repository.addBlock(world.id, targetX, targetY, targetZ, selectedBlockType)
            }
        } else {
            showFeedback("Cannot build outside world borders!")
        }
    }

    fun clickBreakBlock(x: Int, y: Int, z: Int) {
        val world = currentWorld ?: return
        val block = _worldBlocks.value.find { it.x == x && it.y == y && it.z == z }
        if (block != null) {
            spawnParticles(block.x, block.y, block.z, block.type)
            cursorX = x
            cursorY = y
            cursorZ = z
            viewModelScope.launch {
                repository.removeBlock(world.id, x, y, z)
            }
        }
    }

    fun clearAllBlocks() {
        val world = currentWorld ?: return
        viewModelScope.launch {
            repository.clearWorld(world.id)
            showFeedback("World cleared of all blocks!")
        }
    }

    private fun spawnParticles(bx: Int, by: Int, bz: Int, blockType: String) {
        val colorHex = when (blockType) {
            "GRASS" -> "#2ECC71"
            "DIRT" -> "#8D4F2A"
            "STONE" -> "#7F8C8D"
            "WOOD" -> "#A0522D"
            "LEAVES" -> "#27AE60"
            "BRICK" -> "#E74C3C"
            "GLASS" -> "#AED6F1"
            "SAND" -> "#F4D03F"
            "WATER" -> "#3498DB"
            "TNT" -> "#E74C3C"
            "LAVA" -> "#E67E22"
            "DIAMOND" -> "#4DEEEA"
            "GOLD" -> "#F1C40F"
            else -> "#A6ACAF"
        }
        
        val newParticles = mutableListOf<Particle3D>()
        // Spawn 8 small pieces flying in random directions
        for (i in 0..10) {
            val px = bx.toFloat() + 0.5f + (Math.random() - 0.5).toFloat() * 0.4f
            val py = by.toFloat() + 0.5f + (Math.random() - 0.5).toFloat() * 0.4f
            val pz = bz.toFloat() + 0.5f + (Math.random() - 0.5).toFloat() * 0.4f

            val vx = (Math.random() - 0.5).toFloat() * 0.15f
            val vy = (Math.random() * 0.15f + 0.05f).toFloat() // eject upwards
            val vz = (Math.random() - 0.5).toFloat() * 0.15f

            newParticles.add(
                Particle3D(
                    x = px, y = py, z = pz,
                    vx = vx, vy = vy, vz = vz,
                    colorHex = colorHex,
                    life = 1.0f,
                    size = 5f + (Math.random() * 10f).toFloat()
                )
            )
        }
        activeParticles = activeParticles + newParticles
    }

    private fun updateParticles() {
        if (activeParticles.isEmpty()) return
        val updated = activeParticles.mapNotNull { p ->
            p.x += p.vx
            p.y += p.vy
            p.z += p.vz
            p.vy -= 0.015f // gravity pull downwards
            p.life -= 0.05f // decay
            if (p.life > 0f) p else null
        }
        activeParticles = updated
    }
}

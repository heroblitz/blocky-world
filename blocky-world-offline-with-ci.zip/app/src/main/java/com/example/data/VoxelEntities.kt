package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "worlds")
data class WorldEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val type: String, // "flat", "hills", "empty"
    val createdAt: Long = System.currentTimeMillis(),
    val lastUpdated: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "blocks",
    primaryKeys = ["worldId", "x", "y", "z"]
)
data class BlockEntity(
    val worldId: Int,
    val x: Int,
    val y: Int,
    val z: Int,
    val type: String // "GRASS", "DIRT", "STONE", "WOOD", "LEAVES", "BRICK", "GLASS", "SAND", "WATER", "TNT", "LAVA", "DIAMOND", "GOLD"
)

package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface WorldDao {
    @Query("SELECT * FROM worlds ORDER BY lastUpdated DESC")
    fun getAllWorlds(): Flow<List<WorldEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWorld(world: WorldEntity): Long

    @Update
    suspend fun updateWorld(world: WorldEntity)

    @Delete
    suspend fun deleteWorld(world: WorldEntity)

    @Query("SELECT * FROM worlds WHERE id = :worldId")
    suspend fun getWorldById(worldId: Int): WorldEntity?
}

@Dao
interface BlockDao {
    @Query("SELECT * FROM blocks WHERE worldId = :worldId")
    fun getBlocksForWorld(worldId: Int): Flow<List<BlockEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBlock(block: BlockEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBlocks(blocks: List<BlockEntity>)

    @Query("DELETE FROM blocks WHERE worldId = :worldId AND x = :x AND y = :y AND z = :z")
    suspend fun deleteBlock(worldId: Int, x: Int, y: Int, z: Int)

    @Query("DELETE FROM blocks WHERE worldId = :worldId")
    suspend fun clearBlocksForWorld(worldId: Int)
}

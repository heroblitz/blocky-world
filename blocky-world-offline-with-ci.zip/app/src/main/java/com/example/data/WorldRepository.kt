package com.example.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlin.math.cos
import kotlin.math.sin

class WorldRepository(
    private val worldDao: WorldDao,
    private val blockDao: BlockDao
) {
    val allWorlds: Flow<List<WorldEntity>> = worldDao.getAllWorlds()

    fun getBlocksForWorld(worldId: Int): Flow<List<BlockEntity>> {
        return blockDao.getBlocksForWorld(worldId)
    }

    suspend fun insertWorld(world: WorldEntity, prepopulate: Boolean = true): Int {
        val worldId = worldDao.insertWorld(world).toInt()
        if (prepopulate) {
            val blocks = generateInitialBlocks(worldId, world.type)
            blockDao.insertBlocks(blocks)
        }
        return worldId
    }

    suspend fun addBlock(worldId: Int, x: Int, y: Int, z: Int, type: String) {
        if (x in 0..15 && y in 0..15 && z in 0..15) {
            blockDao.insertBlock(BlockEntity(worldId, x, y, z, type))
            // Update world edit time
            worldDao.getWorldById(worldId)?.let { world ->
                worldDao.updateWorld(world.copy(lastUpdated = System.currentTimeMillis()))
            }
        }
    }

    suspend fun removeBlock(worldId: Int, x: Int, y: Int, z: Int) {
        blockDao.deleteBlock(worldId, x, y, z)
        // Update world edit time
        worldDao.getWorldById(worldId)?.let { world ->
            worldDao.updateWorld(world.copy(lastUpdated = System.currentTimeMillis()))
        }
    }

    suspend fun clearWorld(worldId: Int) {
        blockDao.clearBlocksForWorld(worldId)
    }

    suspend fun deleteWorld(world: WorldEntity) {
        blockDao.clearBlocksForWorld(world.id)
        worldDao.deleteWorld(world)
    }

    suspend fun checkAndPrepopulateDefaultWorlds() {
        val currentWorlds = worldDao.getAllWorlds().first()
        if (currentWorlds.isEmpty()) {
            // Prepopulate 3 beautiful sandbox presets!
            val hillsId = insertWorld(
                WorldEntity(
                    name = "Survival Valley 🌲",
                    type = "hills"
                ),
                prepopulate = true
            )
            val flatId = insertWorld(
                WorldEntity(
                    name = "Flat Playground 🧱",
                    type = "flat"
                ),
                prepopulate = true
            )
            val skyblockId = insertWorld(
                WorldEntity(
                    name = "Skyblock Island 🟦",
                    type = "empty"
                ),
                prepopulate = true
            )
        }
    }

    private fun generateInitialBlocks(worldId: Int, type: String): List<BlockEntity> {
        val blocks = mutableListOf<BlockEntity>()
        when (type) {
            "flat" -> {
                for (x in 0..15) {
                    for (z in 0..15) {
                        blocks.add(BlockEntity(worldId, x, 0, z, "STONE"))
                        blocks.add(BlockEntity(worldId, x, 1, z, "DIRT"))
                        blocks.add(BlockEntity(worldId, x, 2, z, "DIRT"))
                        blocks.add(BlockEntity(worldId, x, 3, z, "GRASS"))
                    }
                }
            }
            "hills" -> {
                for (x in 0..15) {
                    for (z in 0..15) {
                        // Terrain math
                        val h = (2.5 * sin(x * 0.4) + 1.5 * cos(z * 0.45) + 4.0).toInt().coerceIn(1, 10)
                        for (y in 0..h) {
                            val material = when {
                                y == h -> "GRASS"
                                y > h - 3 -> "DIRT"
                                else -> "STONE"
                            }
                            blocks.add(BlockEntity(worldId, x, y, z, material))
                        }

                        // Grow an Oak Tree at (4, 4)
                        if (x == 4 && z == 4) {
                            for (ty in (h + 1)..(h + 4)) {
                                blocks.add(BlockEntity(worldId, x = 4, y = ty, z = 4, type = "WOOD"))
                            }
                            for (lx in 3..5) {
                                for (lz in 3..5) {
                                    for (ly in (h + 3)..(h + 4)) {
                                        if (lx == 4 && lz == 4 && ly == h + 3) continue
                                        blocks.add(BlockEntity(worldId, x = lx, y = ly, z = lz, type = "LEAVES"))
                                    }
                                }
                            }
                            blocks.add(BlockEntity(worldId, x = 4, y = h + 5, z = 4, type = "LEAVES"))
                        }

                        // Spawn some Iron & Coal Ore deep underground or on hillsides
                        if (x == 10 && z == 5 && h >= 4) {
                            blocks.add(BlockEntity(worldId, x = 10, y = 2, z = 5, type = "GOLD"))
                        }
                        if (x == 14 && z == 10 && h >= 5) {
                            blocks.add(BlockEntity(worldId, x = 14, y = 3, z = 10, type = "DIAMOND"))
                        }

                        // Add a small splash of static lava or water pond
                        if (((x == 12 || x == 13) && (z == 2 || z == 3)) && h < 5) {
                            // Carve out a tiny hole and fill with LAVA/WATER
                            blocks.add(BlockEntity(worldId, x = x, y = h, z = z, type = "WATER"))
                        }
                    }
                }
            }
            "empty" -> {
                // Skyblock structure: A floating 4x4 dirt platform with an oak tree
                for (x in 6..9) {
                    for (z in 6..9) {
                        blocks.add(BlockEntity(worldId, x, 3, z, "DIRT"))
                        if (x in 7..8 && z in 7..8) {
                            blocks.add(BlockEntity(worldId, x, 4, z, "GRASS"))
                        }
                    }
                }
                // Grow a tree on the skyblock island
                val treeX = 8
                val treeZ = 8
                val h = 4
                for (ty in (h + 1)..(h + 3)) {
                    blocks.add(BlockEntity(worldId, x = treeX, y = ty, z = treeZ, type = "WOOD"))
                }
                for (lx in (treeX - 1)..(treeX + 1)) {
                    for (lz in (treeZ - 1)..(treeZ + 1)) {
                        for (ly in (h + 3)..(h + 4)) {
                            if (lx == treeX && lz == treeZ && ly == h + 3) continue
                            blocks.add(BlockEntity(worldId, x = lx, y = ly, z = lz, type = "LEAVES"))
                        }
                    }
                }
            }
        }
        return blocks
    }
}
